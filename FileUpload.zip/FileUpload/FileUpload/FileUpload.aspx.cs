﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FileUpload
{
    public partial class FileUpload : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string name = TextBox_Name.Text;
            string Dropdown = DropDownList.SelectedValue;
            string fileName = FileUpload1.FileName;
            FileUpload1.SaveAs(Server.MapPath("~/Models/"+fileName));
        }
    }
}
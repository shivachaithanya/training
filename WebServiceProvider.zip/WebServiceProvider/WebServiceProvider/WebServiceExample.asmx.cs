﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace WebServiceProvider
{
    /// <summary>
    /// Summary description for WebServiceExample
    /// </summary>
    [WebService(Namespace = "http://cubussolutions.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebServiceExample : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "You called webservice";
        }
        [WebMethod]
        public double Addnumbers(double firstnum, double secondnum) {
            return firstnum+secondnum;
        }
        [WebMethod]
        public double Subtractnumbers(double firstnum, double secondnum)
        {
            return firstnum - secondnum;
        }
        [WebMethod]
        public double Multiplication(double firstnum, double secondnum)
        {
            return firstnum * secondnum;
        }
        [WebMethod]
        public double Division(double firstnum, double secondnum)
        {
            return (firstnum)/(secondnum);
        }
    }
}

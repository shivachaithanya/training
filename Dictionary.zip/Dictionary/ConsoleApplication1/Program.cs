﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var studentList = new Dictionary<string, double>();
            studentList.Add("shiva", 77);
            studentList.Add("suman", 78);
            studentList.Add("dharaniteja", 79);
            studentList.Add("pradeep", 80);
            studentList.Add("sagar", 81);
            studentList.Add("chandan", 82);
            var studkeys = studentList.Keys;
            Console.WriteLine("number of students:"+studkeys.Count);
            foreach (var keys in studkeys)
            {
                Console.WriteLine(keys+":"+studentList[keys]);

            }
            string[] keysArray = studkeys.ToArray();
            Array.Sort(keysArray);
            foreach (var keys in keysArray)
            {
                Console.WriteLine(keys+":"+studentList[keys]);
            }
            double value;
            if (studentList.TryGetValue("shiva",out value))
            {
                Console.WriteLine("shiva"+value);
            }
            else
            {
                Console.WriteLine("you have entered something!!!!!!!!");
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DetailsStudent
{
    public partial class Display : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            List<StudentDetalis> s = new List<StudentDetalis>();
            s = (List<StudentDetalis>)Session["deserialise"];
            string s1 = Session["text"].ToString();

            var studentDetails_query = from c in s where c.name == s1 select c;
            foreach (var stud_details in studentDetails_query)
            {
                view_Studentid.Text = "student id:" + stud_details.id.ToString();
                view_Studentname.Text = "student name:" + stud_details.name;
                view_Studentdept.Text = "student department:" + stud_details.department;
                view_MathsScore.Text = "maths:" + stud_details.maths.ToString();
                view_PhysicsScore.Text = "physics:" + stud_details.physics.ToString();
                view_ChemistryScore.Text = "chemistry:" + stud_details.chemistry.ToString();
                view_StudentAverage.Text = "Average:" + stud_details.average.ToString();
                view_StudentRemarks.Text = ":" + stud_details.remarks;
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

using System.Xml;
using System.Xml.XPath;

namespace DetailsStudent
{
    public class StudentDetalis
    {
        public StudentDetalis()
        {
        }

        public StudentDetalis(int id, string name, string department, int maths, int physics, int chemistry, double average, string remarks)
        {
            this.id = id;
            this.name = name;
            this.department = department;
            this.maths = maths;
            this.physics = physics;
            this.chemistry = chemistry;
            this.average = average;
            this.remarks = remarks;
        }
        [XmlElement]
        public int id { get; set; }
        [XmlElement]
        public string name { get; set; }
        [XmlElement]
        public string department { get; set; }
        [XmlElement]
        public int maths { get; set; }
        [XmlElement]
        public int physics { get; set; }
        [XmlElement]
        public int chemistry { get; set; }
        [XmlElement]
        public double average { get; set; }
        [XmlElement]
        public string remarks { get; set; }
        public override string ToString()
        {
            return id + " " + name + " " + department + " " + maths + " " + physics + " " + chemistry + "" + average + "" + remarks;
        }
        public List<StudentDetalis> Conversionxml(String path)
        {

            XmlSerializer deserialize = new XmlSerializer(typeof(List<StudentDetalis>));

            TextReader textreader = new StreamReader(path);

            List<StudentDetalis> Stud_Details_Deserialise = null;
            Stud_Details_Deserialise = (List<StudentDetalis>)deserialize.Deserialize(textreader);
            textreader.Close();
            return Stud_Details_Deserialise;
        }
        //public XmlDocument GetEntityXml<T>(StudentDetalis obj)
        //{
        //    XmlDocument xmlDoc = new XmlDocument();
        //    XPathNavigator nav = xmlDoc.CreateNavigator();
        //    using (XmlWriter writer = nav.AppendChild())
        //    {
        //        XmlSerializer ser = new XmlSerializer(typeof(List<StudentDetalis >), new XmlRootAttribute("studentdetail"));
        //        ser.Serialize(writer,obj);
        //    }
        //    return xmlDoc;
        //}
    }
}
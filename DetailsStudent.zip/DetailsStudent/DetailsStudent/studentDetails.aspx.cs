﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Serialization;

namespace DetailsStudent
{
    public partial class studentDetails : System.Web.UI.Page
    {
        private object filemode;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void StudentDetails_Submit_Click(object sender, EventArgs e)
        {
           
            int id = int.Parse(Textbox_StudentId.Text);
            string name = Textbox_StudentName.Text;
            string department = TextBox_StudentDepartment.Text;
            int maths = int.Parse(TextBox_Mathsmarks.Text);
            int physics = int.Parse(TextBox_Physicsmarks.Text);
            int chemistry = int.Parse(TextBox_Chemistrymarks.Text);
            double average = (maths + physics + chemistry) / 3;
            string remarks = "";
            if (average >= 40)
            {
                remarks = "passed";
            }
            else
            {
                remarks = "failed";
            }

            List<StudentDetalis> studentDetails = new List<StudentDetalis>();
            StudentDetalis student = new StudentDetalis(id, name, department, maths, physics, chemistry, average, remarks);
            //var obj= student.GetEntityXml<studentDetails>(student);
            studentDetails.Add(new StudentDetalis(id, name, department, maths, physics, chemistry, average, remarks));

            XmlSerializer serilize = new XmlSerializer(typeof(List<StudentDetalis>));
            TextWriter textwriter = new StreamWriter(@"E:\Studentdetails.xml");
            serilize.Serialize(textwriter, studentDetails);
            //using (var file = File.Open(Server.MapPath("Studentdetails.xml"), FileMode.OpenOrCreate))
            //  serilize.Serialize(file, studentDetails);
            textwriter.Close();

        }

        

        protected void Btn_ViewDetails_Click(object sender, EventArgs e)
        {
            StudentDetalis obj1 = new StudentDetalis();
            var deserialisedata= obj1.Conversionxml(@"E:\Studentdetails.xml");
            string test = TextBox_StudentView.Text;
            Session["deserialise"] = deserialisedata;

            Session["text"] = test;
            Response.Redirect("Display.aspx");
           
        }
    }
    }

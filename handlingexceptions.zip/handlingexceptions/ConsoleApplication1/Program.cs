﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string[] fruits = {"apple",null,"banana" };
                for (int i = 0; i <=fruits.Length; i++)
                {
                    Console.WriteLine(fruits[i]);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
              
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {

            Dictionary<int, StudentName> students = new Dictionary<int, StudentName>();
            students.Add(111, new StudentName { FirstName = "shiva", LastName = "chaitanya",ID=111});
            students.Add(112, new StudentName { FirstName = "suman", LastName = "dasari", ID = 112 });
            students.Add(113, new StudentName { FirstName = "dharani", LastName = "teja", ID = 113 });
            students.Add(114, new StudentName { FirstName = "sagar", LastName = "reddy" , ID = 114 });
            students.Add(115, new StudentName { FirstName = "pradeep", LastName = "reddy", ID = 115 });
            foreach (var item in students)
            {
                Console.WriteLine(item);
            }

        }
        class StudentName
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
            public int ID { get; set; }
            public override string ToString()
            {
                return FirstName + " "+ LastName  +" " + ID;
            }
        }
    }
}

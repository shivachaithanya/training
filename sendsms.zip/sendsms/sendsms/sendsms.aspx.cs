﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace sendsms
{
    public partial class sendsms : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void GenerateRandomOTP(int iOTPLength, string[] saAllowedCharacters)

        {

            string sOTP = String.Empty;

            string sTempChars = String.Empty;

            Random rand = new Random();

            for (int i = 0; i < iOTPLength; i++)

            {

                int p = rand.Next(0, saAllowedCharacters.Length);

                sTempChars = saAllowedCharacters[rand.Next(0, saAllowedCharacters.Length)];

                sOTP += sTempChars;

            }
            var username = ConfigurationManager.AppSettings["username"];
            var password = ConfigurationManager.AppSettings["password"];
            var apikey = ConfigurationManager.AppSettings["apikey"];
            double moblie = Convert.ToDouble(textbox_phonenumber.Text);

            string URL = "https://smsapi.engineeringtgr.com/send/?Mobile=" + username + "&Password=" + password + "&Message=" + sOTP + "&To=" + moblie + "&Key=" + apikey + "";

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(URL);
            request.Method = "GET";
            request.ContentType = "application/json";
            request.ContentLength = 0;// DATA.Length;

            try
            {
                WebResponse webResponse = request.GetResponse();
                Stream webStream = webResponse.GetResponseStream();
                StreamReader responseReader = new StreamReader(webStream);
                string response = responseReader.ReadToEnd();
                Console.Out.WriteLine(response);
                responseReader.Close();
            }
            catch (Exception xe)
            {
                Console.Out.WriteLine("-----------------");
                Console.Out.WriteLine(xe.Message);
            }
        }

        protected void btnSent_Click(object sender, EventArgs e)
        {
            string[] allowedcharacters = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
            int length = 8;
            GenerateRandomOTP(length, allowedcharacters);
        }
    }
}
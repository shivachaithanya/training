﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace WebApplication1
{
    public class Details
    {
        public Details()
        {
        }

        public Details(int id, string name, string department, int maths, int physics, int chemistry, double average, string remarks)
        {
            this.id = id;
            this.name = name;
            this.department = department;
            this.maths = maths;
            this.physics = physics;
            this.chemistry = chemistry;
            this.average = average;
            this.remarks = remarks;
        }
        [XmlElement]
        public int id { get; set; }
        [XmlElement]
        public string name { get; set; }
        [XmlElement]
        public string department { get; set; }
        [XmlElement]
        public int maths { get; set; }
        [XmlElement]
        public int physics { get; set; }
        [XmlElement]
        public int chemistry { get; set; }
        [XmlElement]
        public double average { get; set; }
        [XmlElement]
        public string remarks { get; set; }
        public override string ToString()
        {
            return id + " " + name + " " + department + " " + maths + " " + physics + " " + chemistry + "" + average + "" + remarks;
        }
        public List<Details> Conversionxml(String path)
        {

            XmlSerializer deserialize = new XmlSerializer(typeof(List<Details>));

            TextReader textreader = new StreamReader(path);

            List<Details> details = null;
            details = (List<Details>)deserialize.Deserialize(textreader);
            textreader.Close();
            return details;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace StudentDetailsWebService
{
    public class StudentInfo
    {
        [XmlElement]
        public string studentId { get; set; }
        [XmlElement]
        public string studentName { get; set; }
        [XmlElement]
        public string studentDepartment { get; set; }
        [XmlElement]
        public double maths { get; set; }
        [XmlElement]
        public double physics { get; set; }
        [XmlElement]
        public double chemistry { get; set; }
        [XmlElement]
        public double average { get; set; }
        [XmlElement]
        public string remarks { get; set; }
        
        public StudentInfo()
        {

        }

        public StudentInfo(string studentId, string studentName, string studentDepartment, double maths, double physics, double chemistry,string remarks,double average)
        {
            this.studentId = studentId;
            this.studentName = studentName;
            this.studentDepartment = studentDepartment;
            this.maths = maths;
            this.physics = physics;
            this.chemistry = chemistry;
            this.average = average;
            this.remarks = remarks;
            
        }

       
        public override string ToString()
        {
            return studentId+" "+ studentName + " "+ studentDepartment + " "+ maths + " "+physics+" "+ chemistry + " "+ average + " "+ remarks; 
        }
        public List<StudentInfo> Conversionxml(String path)
        {

            XmlSerializer deserialize = new XmlSerializer(typeof(List<StudentInfo>));

            TextReader textreader = new StreamReader(path);

            List<StudentInfo> Stud_Details_Deserialise = null;
            Stud_Details_Deserialise = (List<StudentInfo>)deserialize.Deserialize(textreader);
            textreader.Close();
            return Stud_Details_Deserialise;
        }
    }
    public class StudentDetailsList
    {

        public List<StudentInfo> studentinfo
        {
            get;
            set;
        }
    }
   
}
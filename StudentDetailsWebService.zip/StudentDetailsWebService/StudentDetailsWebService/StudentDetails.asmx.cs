﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Xml.Serialization;

namespace StudentDetailsWebService
{
    /// <summary>
    /// Summary description for StudentDetails
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class StudentDetails : System.Web.Services.WebService
    {
        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }
        [WebMethod]
        public List<StudentInfo> studentdetails(string studentId, string studentName, string studentDepartment, double maths,double physics, double chemistry)
        {
            double average= (maths + physics+ chemistry)/3;
            string remarks = "";
            if (average >= 40)
            {
                remarks = "passed";
            }
            else
            {
                remarks = "failed";
            }
            List<StudentInfo> studentDetails = new List<StudentInfo>();
            StudentInfo student = new StudentInfo(studentId,studentName,studentDepartment,maths, physics,chemistry, remarks,average);
            //var obj= student.GetEntityXml<studentDetails>(student);
            studentDetails.Add(new StudentInfo(studentId, studentName, studentDepartment, maths, physics, chemistry, remarks, average));

            XmlSerializer serilize = new XmlSerializer(typeof(List<StudentInfo>));
            TextWriter textwriter = new StreamWriter(@"E:\StudentdetailsWebservice.xml");
            serilize.Serialize(textwriter, studentDetails);
            //using (var file = File.Open(Server.MapPath("Studentdetails.xml"), FileMode.OpenOrCreate))
            //  serilize.Serialize(file, studentDetails);
            textwriter.Close();
            StudentInfo obj1 = new StudentInfo();
            var deserialisedata = obj1.Conversionxml(@"E:\StudentdetailsWebservice.xml");
            return deserialisedata;
        }
        [WebMethod]
        public DataSet getdata()
        {
            DataSet studentdata = new DataSet();
            studentdata.ReadXml(@"E:\StudentdetailsWebservice.xml");
            return studentdata;
        }
    }
}

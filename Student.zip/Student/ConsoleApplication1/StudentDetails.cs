﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApplication1
{
    public class StudentDetails
    {
        public StudentDetails()
        {
        }

        public StudentDetails(int id, string name, string department, int maths, int physics, int chemistry, double average, string remarks)
        {
            this.id = id;
            this.name = name;
            this.department = department;
            this.maths = maths;
            this.physics = physics;
            this.chemistry = chemistry;
            this.average = average;
            this.remarks = remarks;
        }
        [XmlElement]
        public int id { get; set; }
        [XmlElement]
        public string name { get; set; }
        [XmlElement]
        public string department { get; set; }
        [XmlElement]
        public int maths { get; set; }
        [XmlElement]
        public int physics { get; set; }
        [XmlElement]
        public int chemistry { get; set; }
        [XmlElement]
        public double average { get; set; }
        [XmlElement]
        public string remarks { get; set; }
        public override string ToString()
        {
            return id + " " + name + " " + department + " " + maths + " " + physics + " " + chemistry + "" + average + "" + remarks;
        }
        public List<StudentDetails> Conversionxml(String path)
        {

            XmlSerializer deserialize = new XmlSerializer(typeof(List<StudentDetails>));

            TextReader textreader = new StreamReader(path);

            List<StudentDetails> obj1 = null;
            obj1 = (List<StudentDetails>)deserialize.Deserialize(textreader);
            textreader.Close();
            return obj1;
        }
    }
}


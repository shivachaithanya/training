﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace ConsoleApplication1
{
    public class Student
    {

        static void Main(string[] args)
        {
            List<StudentDetails> studentDetails = new List<StudentDetails>();

            while (true)
            {
                Console.WriteLine("enter student id");
                int id = int.Parse(Console.ReadLine());
                Console.WriteLine("enter student name");
                string name = Console.ReadLine();
                Console.WriteLine("enter student department");
                string department = Console.ReadLine();
                Console.WriteLine("enter maths marks");
                int maths = int.Parse(Console.ReadLine());
                Console.WriteLine("enter physics marks");
                int physics = int.Parse(Console.ReadLine());
                Console.WriteLine("enter chemistry marks");
                int chemistry = int.Parse(Console.ReadLine());
                double average = (maths + physics + chemistry) / 3;
                string remarks = "";
                if (average >= 40)
                {
                    remarks = "congratulation you have passed!!!!!!!!!!";
                }
                else
                {
                    remarks = "sorry you have failed\t:( better luck next time";
                }
                try
                {
                    StudentDetails student = new StudentDetails(id, name, department, maths, physics, chemistry, average, remarks);

                    studentDetails.Add(new StudentDetails(id, name, department, maths, physics, chemistry, average, remarks));
                    XmlSerializer serilize = new XmlSerializer(typeof(List<StudentDetails>));
                    System.IO.TextWriter textwriter = new StreamWriter(@"Studentdetails.xml");
                    serilize.Serialize(textwriter, studentDetails);
                    textwriter.Close();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);

                }

                Console.WriteLine("Do you want to continue if yes press<y> orelse press any key");

                string message = Console.ReadLine().ToLower();
                if (message.Equals("y"))
                {
                    continue;
                }
                else
                {
                    Console.WriteLine("do you want to know student details enter student name");
                    StudentDetails obj1 = new StudentDetails();
                    var ds = obj1.Conversionxml(@"Studentdetails.xml");
                    string test = Console.ReadLine().ToLower();
                    var s = from c in ds where c.name == test select c;
                    foreach (var item in s)

                    {
                        Console.WriteLine("student details are:" + "\n" + "studentid:" + item.id + "\n" + "studentname:" + item.name + "\n" + "department:" + item.department + "\n" + "maths:" + item.maths + "\n" + "physics:" + item.physics + "\n" + "chemistry:" + item.chemistry + "\n" + "avearge:" + item.average + "\n" + "remarks:" + item.remarks);
                    }

                    break;
                }
            }
        }
    }
}


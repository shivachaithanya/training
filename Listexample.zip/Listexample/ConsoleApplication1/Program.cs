﻿using ConsoleApplication1.Module;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            var studentReport = new List<StudentReport>();
            studentReport.Add(new StudentReport(1, "shiva", "chaitanya reddy"));
            studentReport.Add(new StudentReport(2, "suman", "dasari"));
            studentReport.Add(new StudentReport(3, "rachana", "reddy"));
            studentReport.Add(new StudentReport(4, "pradeep", "reddy"));
            studentReport.Add(new StudentReport(5, "dharani", "teja"));
            foreach (var item in studentReport)
            {
                Console.WriteLine("the students are:"+item);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            string operation = Console.ReadLine();
            switch (operation)
            {
                case "+":
                    Console.WriteLine("you choose to add");
                    break;
                case "-":
                    Console.WriteLine("you choose to subtract");
                    break;
                case "*":
                    Console.WriteLine("you choose to multiply");
                    break;
                case "/":
                    Console.WriteLine("you choose to divide");
                    break;
                case "%":
                    Console.WriteLine("you choose modulus");
                    break;
                default:
                    Console.WriteLine("no such operation exists");
                    break;

            }
        }
    }
}

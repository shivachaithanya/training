﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ClientApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            MyWebService.WebServiceExampleSoapClient client = new MyWebService.WebServiceExampleSoapClient();
            string hello = client.HelloWorld();
            textBlock.Text = hello;

        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            double firstnumber = Convert.ToDouble(textBox.Text);
            double lastnumber = Convert.ToDouble(textBox1.Text);
            MyWebService.WebServiceExampleSoapClient client = new MyWebService.WebServiceExampleSoapClient();
            double result = client.Addnumbers(firstnumber,lastnumber);
            textBlock.Text = "Result is: " + result;
                }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            double firstnumber = Convert.ToDouble(textBox.Text);
            double lastnumber = Convert.ToDouble(textBox1.Text);
            MyWebService.WebServiceExampleSoapClient client = new MyWebService.WebServiceExampleSoapClient();
            double result = client.Subtractnumbers(firstnumber, lastnumber);
            textBlock.Text = "Result is: " + result;

        }

        private void button2_Click(object sender, RoutedEventArgs e)
        {
            double firstnumber = Convert.ToDouble(textBox.Text);
            double lastnumber = Convert.ToDouble(textBox1.Text);
            MyWebService.WebServiceExampleSoapClient client = new MyWebService.WebServiceExampleSoapClient();
            double result = client.Multiplication(firstnumber, lastnumber);
            textBlock.Text = "Result is: " + result;

        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            double firstnumber = Convert.ToDouble(textBox.Text);
            double lastnumber = Convert.ToDouble(textBox1.Text);
            MyWebService.WebServiceExampleSoapClient client = new MyWebService.WebServiceExampleSoapClient();
            double result = client.Division(firstnumber, lastnumber);
            textBlock.Text = "Result is: " + result;

        }
    }
}

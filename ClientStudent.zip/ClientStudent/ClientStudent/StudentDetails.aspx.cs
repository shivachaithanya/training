﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ClientStudent
{
    public partial class StudentDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button_submit_Click(object sender, EventArgs e)
        {
            string studentid = TextBox_studentid.Text;
            string studentname = TextBox_studentname.Text;
            string studentdepartment = TextBox_department.Text;
            double mathsmarks = Convert.ToDouble(TextBox_mathsmarks.Text);
            double physicsmarks = Convert.ToDouble(TextBox_physicsmarks.Text);
            double chemistrymarks = Convert.ToDouble(TextBox_chemistrymarks.Text);
            WebserviceStudent.StudentDetailsSoapClient student = new WebserviceStudent.StudentDetailsSoapClient();
            student.studentdetails(studentid,studentname,studentdepartment,mathsmarks,physicsmarks,chemistrymarks);
            System.Data.DataSet studenntdetails =  student.getdata();
            GridView_StudentDetails.DataSource = studenntdetails;
            GridView_StudentDetails.DataBind();

        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Employee
    {
        public Employee() { }
        private string name;
        private string empid;
        private float empsalary;
        private string empname;

        public Employee(string empname, string empid, float empsalary)
        {
            this.empname = empname;
            this.empid = empid;
            this.empsalary = empsalary;
        }

        public string Name
        {
            get
            {
                return name;
            }

            set
            {
                name = value;
            }
        }

        public string Empid
        {
            get
            {
                return empid;
            }

            set
            {
                empid = value;
            }
        }

        public float Empsalary
        {
            get
            {
                return empsalary;
            }
            set
            {
                empsalary = value;
            }
        }

        public string Empname
        {
            get
            {
                return empname;
            }

            set
            {
                empname = value;
            }
        }
    }
    class Company :Employee
    {
        public Company()
        {
        }
        public Company(String empname, string empid, float empsalary) : base(empname, empid, empsalary)
        {
        }
        public override string ToString()
        {
            return Empname + " " + Empid + " " + Empsalary;
        }
    }
}

